import React, { useEffect } from "react";

import { Routing } from "./routes/routing";




export default function App() {

  return (
    <>


      <Routing />
    </>
  );
}
